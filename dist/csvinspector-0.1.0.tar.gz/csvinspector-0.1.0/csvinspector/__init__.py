# csvinspector/__init__.py

from .inspector import CSVInspector
